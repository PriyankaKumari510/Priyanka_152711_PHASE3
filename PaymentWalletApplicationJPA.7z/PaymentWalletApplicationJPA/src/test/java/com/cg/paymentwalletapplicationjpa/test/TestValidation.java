package com.cg.paymentwalletapplicationjpa.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.paymentwalletapplicationjpa.dao.IPaymentDao;
import com.cg.paymentwalletapplicationjpa.dao.PaymentDaoImpl;
import com.cg.paymentwalletapplicationjpa.dto.Customer;
import com.cg.paymentwalletapplicationjpa.dto.Wallet;
import com.cg.paymentwalletapplicationjpa.exception.PaymentException;
import com.cg.paymentwalletapplicationjpa.service.IPaymentService;
import com.cg.paymentwalletapplicationjpa.service.PaymentServiceImpl;


public class TestValidation {
	IPaymentService service=new PaymentServiceImpl();
	IPaymentDao dao=new PaymentDaoImpl();

	@Test
	public void CheckForZeroDeposittest() throws PaymentException {
		boolean condition = false;
		Customer customer = new Customer();
		customer.setName("Priyanka");
		customer.setPhNumber("7095804719");
		customer.setEmailId("priya@gmail.com");
		customer.setUserId("priya");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		dao.createAccount(customer);
		condition = service.deposit("priya", 0.0);
		assertFalse(condition);
	}

	@Test(expected = PaymentException.class)
	public void CheckForInvalidNameTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("fd65f46");
		customer.setPhNumber("7095804719");
		customer.setEmailId("priya@gmail.com");
		customer.setUserId("priya");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		service.validateDetails(customer);
	}

	@Test
	public void CheckForValidNameTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Priyanka");
		customer.setPhNumber("7095804719");
		customer.setEmailId("priya@gmail.com");
		customer.setUserId("priya");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertTrue(condition);
	}

	@Test(expected = PaymentException.class)
	public void CheckForInvalidPhoneNumberTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Priyanka");
		customer.setPhNumber("70958");
		customer.setEmailId("priya@gmail.com");
		customer.setUserId("priya");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertFalse(condition);
	}

	@Test
	public void CheckForValidPhoneNumberTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Priyanka");
		customer.setPhNumber("7095804719");
		customer.setEmailId("priya@gmail.com");
		customer.setUserId("priya");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertTrue(condition);
	}

	@Test(expected = PaymentException.class)
	public void CheckForInvalidEmailTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Priyanka");
		customer.setPhNumber("7095804719");
		customer.setEmailId("4gfgaff");
		customer.setUserId("priya");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertFalse(condition);
	}

	@Test
	public void CheckForValidEmailTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Priyanka");
		customer.setPhNumber("7095804719");
		customer.setEmailId("priya@gmail.com");
		customer.setUserId("priya");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertTrue(condition);
	}

	@Test(expected = PaymentException.class)
	public void CheckForInvalidUserId() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Priyanka");
		customer.setPhNumber("7095804719");
		customer.setEmailId("priya@gmail.com");
		customer.setUserId("abc");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertFalse(condition);

	}

	@Test
	public void CheckForValidUserId() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Priyanka");
		customer.setPhNumber("7095804719");
		customer.setEmailId("priya@gmail.com");
		customer.setUserId("priya");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertTrue(condition);

	}

	@Test(expected = PaymentException.class)
	public void CheckForInvalidassword() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Priyanka");
		customer.setPhNumber("7095804719");
		customer.setEmailId("priya@gmail.com");
		customer.setUserId("priya");
		Wallet wallet = new Wallet();
		wallet.setPassword("123");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertFalse(condition);

	}

	@Test
	public void CheckForValidPassword() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Priyanka");
		customer.setPhNumber("7095804719");
		customer.setEmailId("priya@gmail.com");
		customer.setUserId("priya");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertTrue(condition);

	}

}
