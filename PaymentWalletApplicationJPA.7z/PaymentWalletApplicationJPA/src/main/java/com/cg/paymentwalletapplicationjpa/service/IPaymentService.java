package com.cg.paymentwalletapplicationjpa.service;

import com.cg.paymentwalletapplicationjpa.dto.Customer;
import com.cg.paymentwalletapplicationjpa.exception.PaymentException;

public interface IPaymentService {
	public void createAccount(Customer customer);

	public double showBalance(String phNumber);

	public boolean deposit(String phNumber, double amount);

	public boolean withdraw(String phNumber, double amount);

	public boolean fundTransfer(String phSender, String phReceiver, double amount) throws PaymentException;

	public boolean validateDetails(Customer customer) throws PaymentException;

	public Customer login(String id, String password) throws PaymentException;

	public String printTransaction(String userId);
}
